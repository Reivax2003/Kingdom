﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GiveResources : MonoBehaviour
{
    public int resource; //Gold, Wood, Food, Population, Metal, Stone
    public float interval;
    public int amount;
    private GameObject resourceManager;

    // Update is called once per frame
    void Start()
    {
        resourceManager = GameObject.Find("RESOURCE MANAGER");
        StartCoroutine(Wait());
    }
    IEnumerator Wait(){
        yield return new WaitForSecondsRealtime(interval);
        int newAmount = amount+((transform.GetComponent<BuildingStats>().Level-1)*amount);
        resourceManager.SendMessage("addAmount", new int[]{resource, newAmount});
        StartCoroutine(Wait());
    }
}
