using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class PlaceThing : MonoBehaviour
{
    int rotationcounter = 1;
    public GameObject MainBuilding, House, Church, Storage, Bar, RoadShop, CarpetShop, Armory, Cannon, Wall, Farm, Fence, Lantern, Road; 

    public GameObject Ground, parent, peopleHolder, resourceHolder;
    //order of resources: Gold, Wood, Food, Population, Metal, Stone
    public int[][] prices = {new int[]{500, 0, 0, 0, 0, 0}, new int[]{40, 20, 0, 0, 0, 5}, new int[]{100, 20, 0, 0, 10, 80}, new int[] { 50, 60, 0, 0, 10, 20 }, new int[]{50, 100, 0, 0, 0, 50}, new int[]{10, 10, 0, 0, 0, 5}, new int[]{2, 5, 0, 0, 0, 0}, new int[]{100, 0, 0, 0, 50, 0}, new int[] { 100, 0, 0, 0, 50, 0 }, new int[] { 100, 100, 0, 0, 5, 10 }, new int[] { 100, 20, 0, 0, 0, 20 }, new int[] { 10, 5, 0, 0, 0, 0 }, new int[] { 20, 0, 0, 0, 10, 0 }, new int[] {20, 0, 0, 0, 0, 25} };

    public int Houses = 0, Churches = 0, Storages = 0, Bars = 0, RoadShops = 0, CarpetShops = 0, Armories = 0, Cannons = 0, Walls = 0, Farms = 0, Fences = 0, Lanterns = 0, Roads = 0;

    public GameObject[] order;
    public GameObject currentBuilding = null;
    private GameObject ghost = null;
    public Material ghostMaterial, CantPlace;
    public float yPos = 1f;
    private bool canPlace = true;
    private Transform[] ts;
    public AudioSource buildingSound;

    public BuildingTypes script;

    // Update is called once per frame
    void Start(){
        order = new GameObject[14]{ MainBuilding, 
                                    House, Church, Storage, Bar, RoadShop, CarpetShop,
                                    Armory, Cannon, Wall,
                                    Farm, Fence, 
                                    Lantern, Road};
    }
    void Update()
    {
        if (currentBuilding != null) {
            int index = -1;
            for (int i = 0; i < order.Length; i++){
                if (order[i] == currentBuilding)
                    index = i;
            }
            int[] curAmount = resourceHolder.GetComponent<ResourceManager>().amount;
            bool canBuy = true;
            for (int i = 0; i < curAmount.Length; i++){
                if (prices[index][i] > curAmount[i])
                    canBuy = false;
            }

            if (Input.GetMouseButtonDown(0)){

                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;
                if (EventSystem.current.IsPointerOverGameObject()){
                    Debug.Log("Over UI");
                }
                else if (Physics.Raycast(ray, out hit, 1000) && Input.mousePosition.y > 30 && canPlace && canBuy) {
                    GameObject newBuild = Instantiate(currentBuilding, new Vector3(hit.point.x, hit.transform.position.y+hit.transform.localScale.y/4+(currentBuilding.transform.lossyScale.y/2), hit.point.z)+currentBuilding.transform.position, Quaternion.identity, parent.transform);
                    newBuild.layer = 0;
                    newBuild.transform.Rotate(0, (rotationcounter-1) * 45, 0, relativeTo: Space.Self);

                    for (int i = 0; i < prices[index].Length; i++){
                        resourceHolder.SendMessage("spendAmount", new int[2]{i, prices[index][i]});
                    }

                    if (currentBuilding.name == MainBuilding.name) {
                        for (int i = 0; i < 5; i++)
                            peopleHolder.SendMessage("summonPerson", newBuild);
                        script.Appear();
                    } 
                    else if (currentBuilding.name == House.name){
                        for (int i = 0; i < 2; i++)
                            peopleHolder.SendMessage("summonPerson", newBuild);
                        resourceHolder.SendMessage("loseHappiness", 2);
                        Houses++;
                    } 
                    else if (currentBuilding.name == Farm.name){
                        Farms++;
                    } 
                    else if (currentBuilding.name == Storage.name){
                        resourceHolder.SendMessage("addMax");
                        Storages++;
                    }
                    else if (currentBuilding.name == Bar.name){
                        resourceHolder.SendMessage("addHappiness", 5);
                        resourceHolder.SendMessage("loseTrust", 2);
                        Bars++;
                    }
                    else if (currentBuilding.name == Church.name){
                        resourceHolder.SendMessage("addTrust", 5);
                        resourceHolder.SendMessage("loseHappiness", 2);
                        Churches++;
                    }
                    else if (currentBuilding.name == Armory.name){
                        Armories++;
                    }
                    else if (currentBuilding.name == RoadShop.name){
                        RoadShops++;
                    }
                    else if (currentBuilding.name == CarpetShop.name){
                        CarpetShops++;
                    }
                    else if (currentBuilding.name == Cannon.name){
                        Cannons++;
                    }
                    else if (currentBuilding.name == Wall.name){
                        Walls++;
                    }
                    else if (currentBuilding.name == Fence.name){
                        Fences++;
                    }
                    else if (currentBuilding.name == Farm.name){
                        Farms++;
                    }
                  
                    if (!Input.GetKey(KeyCode.LeftShift)){
                        currentBuilding = null;
                        rotationcounter = 1;
                    }

                    buildingSound.Play(0);
                }
            }
            else {
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;

                if (Physics.Raycast(ray, out hit, 1000) && Input.mousePosition.y > 30) {
                    if (hit.transform.tag == "blockPlacing")
                        canPlace = false;
                    if (ghost == null){
                        ghost = Instantiate(currentBuilding, new Vector3(hit.point.x, hit.transform.position.y+hit.transform.localScale.y/4+(currentBuilding.transform.localScale.y/2), hit.point.z)+currentBuilding.transform.position, Quaternion.identity, parent.transform);
                        ghost.name = "ghost";
                        ghost.GetComponent<Renderer>().material = ghostMaterial;
                        ghost.layer = 2;
                        if (!canPlace || !canBuy)
                            ghost.GetComponent<Renderer>().material = CantPlace;
                        ts = ghost.GetComponentsInChildren<Transform>();
                        for (int i = 0; i < ts.Length; i++)
                        {
                            ts[i].GetComponent<Renderer>().material = ghost.GetComponent<Renderer>().material;
                        }
                    }
                    else{
                        ghost.GetComponent<Renderer>().material = ghostMaterial;
                        ghost.layer = 2;
                        if (Input.GetKeyDown("z"))
                        {
                            Debug.Log(rotationcounter);
                            ghost.transform.Rotate(0,45, 0, relativeTo: Space.Self);
                            rotationcounter++;
                        }
                        if (Input.GetKeyDown("x"))
                        {
                            Debug.Log(rotationcounter);
                            ghost.transform.Rotate(0,-45, 0, relativeTo: Space.Self);
                            rotationcounter--;
                        }
                        if (!canPlace || !canBuy)
                            ghost.GetComponent<Renderer>().material = CantPlace;

                        for (int i = 0; i < ts.Length; i++)
                        {
                            ts[i].GetComponent<Renderer>().material = ghost.GetComponent<Renderer>().material;
                        }
                        ghost.transform.position = new Vector3(hit.point.x, hit.transform.position.y+hit.transform.localScale.y/4+(currentBuilding.transform.localScale.y/2), hit.point.z)+currentBuilding.transform.localPosition;
                    }
                }
            }
            if (Input.GetMouseButtonDown(1)) {
                currentBuilding = null;
                Destroy(ghost);
            }

        }
        else if (ghost != null) {
            Destroy(ghost);
        }
    }

    public void useMainBuilding(){
        currentBuilding = MainBuilding;
        canPlace = true;
        if (ghost != null)
        {
            Destroy(ghost);
        }
    }

    public void useHouse(){
        currentBuilding = House;
        canPlace = true;
        if (ghost != null){
            Destroy(ghost);
        }
    }
    public void useChurch(){
        currentBuilding = Church;
        canPlace = true;
        if (ghost != null) {
            Destroy(ghost);
        }

    }
    public void useStorage()
    {
        currentBuilding = Storage;
        canPlace = true;
        if (ghost != null)
        {
            Destroy(ghost);
        }
    }
    public void useBar(){
        currentBuilding = Bar;
        canPlace = true;
        if (ghost != null)
        {
            Destroy(ghost);
        }

    }
    public void useRoadShop(){
        currentBuilding = RoadShop;
        canPlace = true;
        if (ghost != null)
        {
            Destroy(ghost);
        }

    }
    public void useCarpetShop(){
        currentBuilding = CarpetShop;
        canPlace = true;
        if (ghost != null)
        {
            Destroy(ghost);
        }

    }
    public void useArmory(){
        currentBuilding = Armory;
        canPlace = true;
        if (ghost != null)
        {
            Destroy(ghost);
        }

    }
    public void useCannon(){
        currentBuilding = Cannon;
        canPlace = true;
        if (ghost != null)
        {
            Destroy(ghost);
        }
    }
    public void useWall()
    {
        currentBuilding = Wall;
        canPlace = true;
        if (ghost != null)
        {
            Destroy(ghost);
        }

    }
    public void useFarm(){
        currentBuilding = Farm;
        canPlace = true;
        if (ghost != null)
        {
            Destroy(ghost);
        }
    }
    public void useFence(){
        currentBuilding = Fence;
        canPlace = true;
        if (ghost != null)
        {
            Destroy(ghost);
        }
    }
    public void useLantern(){
        currentBuilding = Lantern;
        canPlace = true;
        if (ghost != null)
        {
            Destroy(ghost);
        }
    }
    public void useRoad(){
        currentBuilding = Road;
        canPlace = true;
        if (ghost != null)
        {
            Destroy(ghost);
        }
    }


    private void intersecting() {
        canPlace = false;
    }
    private void nonIntersecting() {
        canPlace = true;
    }
}
