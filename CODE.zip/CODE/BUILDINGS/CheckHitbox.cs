﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckHitbox : MonoBehaviour
{
    void OnTriggerEnter(Collider other){
        if (other.tag != "IgnoreBuildings"){
            Camera.main.SendMessage("intersecting");
        }
    }
    void OnTriggerStay(Collider other){
        if (other.tag != "IgnoreBuildings"){
            Camera.main.SendMessage("intersecting");
        }
    }
    void OnTriggerExit(Collider other){
        if (other.tag != "IgnoreBuildings"){
            Camera.main.SendMessage("nonIntersecting");
        }
    }
}
