﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimalWander : MonoBehaviour
{
    public Rigidbody rb;

    // Update is called once per frame
    void Update()
    {
        if (transform.position.y < 10){
            if (Random.Range(0f, 2000f) > 1990){
                rb.AddRelativeTorque(new Vector3(0f, Random.Range(-10f, 10f)*Time.deltaTime*10000, 0f));
                //rb.AddRelativeForce(new Vector3(0f, 0f, Random.Range(1000f, 10000f)*Time.deltaTime));
                rb.AddExplosionForce(250, transform.position, 2, 5);
            }
            if (Random.Range(0f, 1000000f) <= 1){
                rb.AddExplosionForce(25000, transform.position, 20, 50);
            }
        }
        else{
            rb.velocity = new Vector3(rb.velocity.x, rb.velocity.y/1.05f, rb.velocity.z);
        }
    }
}
