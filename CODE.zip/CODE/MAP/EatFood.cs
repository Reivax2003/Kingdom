﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EatFood : MonoBehaviour
{
    public int resource = 2; //Gold, Wood, Food, Population, Metal, Stone
    public int amount;
    private GameObject resourceManager;

    // Update is called once per frame
    void Start()
    {
        resourceManager = GameObject.Find("RESOURCE MANAGER");
        StartCoroutine(Wait());
    }
    IEnumerator Wait(){
        yield return new WaitForSecondsRealtime(10);
        int newAmount = resourceManager.GetComponent<ResourceManager>().Population;
        resourceManager.SendMessage("spendAmount", new int[]{resource, newAmount});
        StartCoroutine(Wait());
    }
}
