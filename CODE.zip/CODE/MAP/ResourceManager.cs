﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResourceManager : MonoBehaviour
{
    public int Gold, Wood, Food, Population, Metal, Stone;
    public float maxGold, maxWood, maxFood, maxPopulation, maxMetal, maxStone;
    public string[] order = new string[] {"gold", "wood", "food", "population", "metal" ,"stone"};
    public int[] amount = new int[6];
    public float[] maximum = new float[6];

    void Start()
    {
        amount = new int[] {Gold, Wood, Food, Population, Metal, Stone};
        maximum = new float[] {Mathf.Infinity, maxWood, maxFood, Mathf.Infinity, maxMetal, maxStone};
    }
    public void addAmount(int[] lst)
    {
        amount[lst[0]] += lst[1];
        if (amount[lst[0]] > maximum[lst[0]]){
            amount[lst[0]] = (int) maximum[lst[0]];
        }
        updateVars();
    }
    public void spendAmount(int[] lst)
    {
        amount[lst[0]] -= lst[1];

        if (amount[lst[0]] < 0) {
            amount[lst[0]] = 0;
        }

        updateVars();
    }
    public void addMax()
    {
        for(int i = 0; i < maximum.Length; i++){
            maximum[i] += 50;
        }
        updateVars();
    }
    public void subtractMax()
    {
        for(int i = 0; i < maximum.Length; i++){
            maximum[i] -= 50;
        }
        updateVars();
    }

    public void updateVars(){
        Gold = amount[0];
        Wood = amount[1];
        Food = amount[2];
        Population = amount[3];
        Metal = amount[4];
        Stone = amount[5];
        maxGold = maximum[0];
        maxWood = maximum[1];
        maxFood = maximum[2];
        maxPopulation = maximum[3];
        maxMetal = maximum[4];
        maxStone = maximum[5];
    }
}
