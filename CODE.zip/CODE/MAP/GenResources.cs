﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenResources : MonoBehaviour
{
    public float yPos = 2.5f;
    public GameObject tree;
    public GameObject rock;
    public GameObject cow;
    public GameObject sheep;
    public GameObject pig;
    public GameObject duck;
    public GameObject chicken;
    public int minx = 0;
    public int maxx = 10;
    public int miny = 0;
    public int maxy = 10;
    public GameObject parent;
    // Start is called before the first frame update
    void Start()
    {
        int amount = (maxy-miny)*(maxx-minx)/175;

        for (int i = 0; i < amount; i++){
            float x = Random.Range((float) minx, (float) maxx);
            float z = Random.Range((float) miny, (float) maxy);
            Instantiate(tree, new Vector3(x, yPos, z), Quaternion.identity, parent.transform);
        }
        for (int i = 0; i < amount; i++){
            float x = Random.Range((float) minx, (float) maxx);
            float z = Random.Range((float) miny, (float) maxy);
            Instantiate(rock, new Vector3(x, yPos, z), Quaternion.identity, parent.transform);
        }
        for (int i = 0; i < amount / 25; i++){
            float x = Random.Range((float)minx, (float)maxx);
            float z = Random.Range((float)miny, (float)maxy);
            Instantiate(cow, new Vector3(x, yPos, z), Quaternion.identity, parent.transform);
        }
        for (int i = 0; i < amount / 25; i++){
            float x = Random.Range((float)minx, (float)maxx);
            float z = Random.Range((float)miny, (float)maxy);
            Instantiate(sheep, new Vector3(x, yPos, z), Quaternion.identity, parent.transform);
        }
        for (int i = 0; i < amount / 25; i++){
            float x = Random.Range((float)minx, (float)maxx);
            float z = Random.Range((float)miny, (float)maxy);
            Instantiate(pig, new Vector3(x, yPos, z), Quaternion.identity, parent.transform);
        }
        for (int i = 0; i < amount / 25; i++){
            float x = Random.Range((float)minx, (float)maxx);
            float z = Random.Range((float)miny, (float)maxy);
            Instantiate(duck, new Vector3(x, yPos, z), Quaternion.identity, parent.transform);
        }
        for (int i = 0; i < amount / 25; i++){
            float x = Random.Range((float)minx, (float)maxx);
            float z = Random.Range((float)miny, (float)maxy);
            Instantiate(chicken, new Vector3(x, yPos, z), Quaternion.identity, parent.transform);
        }
        transform.Rotate(0f, 45f, 0f);
    }
}
