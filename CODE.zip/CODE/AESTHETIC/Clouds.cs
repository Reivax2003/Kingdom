﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Clouds : MonoBehaviour
{
    public int minGen, maxGen, start, y;
    public GameObject parent;
    public GameObject[] choices;
    void Update()
    {
        if (Random.Range(0, 10000*Time.deltaTime) >= 500){
            int pos = Random.Range(minGen, maxGen);
            GameObject newCloud = Instantiate(choices[Random.Range(0, choices.Length-1)], new Vector3(pos, y, start-(pos-230)), Quaternion.identity, parent.transform);
            newCloud.transform.localScale = new Vector3(0, 0, 0);
            newCloud.transform.Rotate(new Vector3(0, 45, 0));
        }
    }
}
