﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwimAcross : MonoBehaviour
{
    void Update()
    {
        transform.position -= new Vector3(5, 0, -5)*Time.deltaTime;
        if (transform.localPosition.x < -200){
            Destroy(transform.gameObject);
        }
    }
}
