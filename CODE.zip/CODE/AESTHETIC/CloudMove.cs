﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CloudMove : MonoBehaviour
{
    // Update is called once per frame
    void Update()
    {
        transform.position -= new Vector3(2, 0, 2)*Time.deltaTime;
        if (transform.localPosition.z <= -10){
            transform.localScale -= new Vector3(1, 1, 1)*Time.deltaTime;
        }
        else if (transform.localScale.x < 0.3f){
            transform.localScale += new Vector3(1, 1, 1)*Time.deltaTime;
        }
        else if (transform.localScale.x > 0.3f){
            transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
        }
        if (transform.localScale.x <= 0){
            Destroy(transform.gameObject);
        }
    }
}
