﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SeaMonsters : MonoBehaviour
{
    public int minGen, maxGen, start, y;
    public GameObject parent;
    public GameObject prefab;
    void Update()
    {
        if (Random.Range(0, 10000*Time.deltaTime) >= 700){
            int pos = Random.Range(minGen, maxGen);
            GameObject monster = Instantiate(prefab, new Vector3(start+pos, y, pos), Quaternion.identity, parent.transform);
            monster.transform.Rotate(new Vector3(0, -45, 0));
        }
    }
}
