﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrackProgress : MonoBehaviour
{
    public float hp;
    public float currentHp;
    public GameObject resourceHolder;
    public bool isDead = false;
    public int deaths = 0;
    public Animator animator;
    // Start is called before the first frame update
    void Start(){
        resourceHolder = GameObject.Find("RESOURCE MANAGER");
        currentHp = hp;
        if (transform.name == "CowBIW(Clone)" || transform.name == "ChickenBrown(Clone)" || transform.name == "DuckWhite(Clone)" || transform.name == "Pig(Clone)" || transform.name == "SheepWhite(Clone)")
            deaths = 4;
    }
    void takeDamage(float amount){
        if (!isDead){
            currentHp -= amount;
            animator.SetBool("isBeingHit", true);
        }
        if (currentHp <= 0 && !isDead){
            animator.SetBool("isBeingHit", false);
            int reward = 0;
            isDead = true;
            deaths++;
            if (transform.name == "Fir_Tree(Clone)"){
                reward = Random.Range(15, 25);
                resourceHolder.SendMessage("addAmount", new int[2]{1, reward});
            }
            else if (transform.name == "Rock1(Clone)"){
                reward = Random.Range(8, 12);
                resourceHolder.SendMessage("addAmount", new int[2]{5, reward});
                reward = Random.Range(0, 5);
                resourceHolder.SendMessage("addAmount", new int[2]{4, reward});
            }
            else if (transform.name == "CowBIW(Clone)"){
                reward = Random.Range(15, 25);
                resourceHolder.SendMessage("addAmount", new int[2]{2, reward});
            }
            else if (transform.name == "ChickenBrown(Clone)"){
                reward = Random.Range(5, 10);
                resourceHolder.SendMessage("addAmount", new int[2]{2, reward});
            }
            else if (transform.name == "DuckWhite(Clone)"){
                reward = Random.Range(2, 5);
                resourceHolder.SendMessage("addAmount", new int[2]{2, reward});
            }
            else if (transform.name == "Pig(Clone)"){
                reward = Random.Range(10, 20);
                resourceHolder.SendMessage("addAmount", new int[2]{2, reward});
            }
            else if (transform.name == "SheepWhite(Clone)"){
                reward = Random.Range(8, 15);
                resourceHolder.SendMessage("addAmount", new int[2]{2, reward});
            }
            currentHp = hp;
            StartCoroutine(Wait());
        }
        if (deaths >= 5)
            Destroy(transform.gameObject);
    }
    void stopTask(){
        animator.SetBool("isBeingHit", false);
    }
    IEnumerator Wait(){
        yield return new WaitForSecondsRealtime(1f);
        isDead = false;
    }
}
