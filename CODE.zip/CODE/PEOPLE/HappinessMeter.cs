﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HappinessMeter : MonoBehaviour
{
    public int happiness;
    public GameObject resourceHolder; 
    //public int houses, bars, churches, walls, cannons, armyBases;
    private PlaceThing varHolder;
    public int population;
    public bool showHappiness = true;
    public GameObject LosePanel;
    public ShowStats showStats;
    private int decisionEffect = 0;

    // Update is called once per frame
    void Start(){
        varHolder = Camera.main.GetComponent<PlaceThing>();
        population = resourceHolder.GetComponent<ResourceManager>().Population;
    }
    void OnGUI()
    {
        population = resourceHolder.GetComponent<ResourceManager>().Population;
        int armyImpact = (int) (Mathf.Pow(((float) varHolder.Armories/2f)-((float) population/2f), 2f));
        if (armyImpact < 0)
            armyImpact = 0;
        happiness = 100 + (5*varHolder.Bars) - armyImpact - (2*varHolder.Churches) - varHolder.Houses*2 - (varHolder.Cannons+varHolder.Walls)/5 + (varHolder.CarpetShops+varHolder.RoadShops)*2 + decisionEffect + (resourceHolder.GetComponent<ResourceManager>().Food - population*5);

        GUIStyle myStyle = new GUIStyle();
        myStyle.fontSize = 35;
        myStyle.normal.textColor = Color.white;

        if (happiness == 0) {
            showHappiness = !showHappiness;
            LosePanel.gameObject.SetActive(true);
            showStats.hideText();
            Time.timeScale = 0;
        }

        if (showHappiness) {
            if (happiness > 100)
                GUI.Label(new Rect(220, 0, 200, 20), "Happiness: 100%", myStyle);
            else
                GUI.Label(new Rect(220, 0, 200, 20), "Hapiness: " + happiness.ToString() + "%", myStyle);
        }
    }
    public void addHappiness(int amount){
        happiness += amount;
    }
    public void loseHappiness(int amount){
        happiness -= amount;
    }

    public void showHappText() {
        showHappiness = true;
    }

    public void hideHappText() {
        showHappiness = false;
    }
    public void makeDecision(bool yes){
        if (yes)
            decisionEffect -= 5;
        else   
            decisionEffect += 5;
    }
    
}
