﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrustMeter : MonoBehaviour
{
    public int trust;
    public GameObject resourceHolder;
    private PlaceThing varHolder;
    //public int bars, churches, armyBases, population;
    public bool showTrust = true;
    public int population;
    public GameObject LosePanel;
    public ShowStats showStats;
    private int decisionEffect = 0;

    void Start(){
        varHolder = Camera.main.GetComponent<PlaceThing>();
        population = resourceHolder.GetComponent<ResourceManager>().Population;
    }
    void OnGUI()
    {
        int peopleFactor = varHolder.Houses/5;
        trust = 100 - (2*varHolder.Bars) + (varHolder.Armories/4) + (5*varHolder.Churches) - peopleFactor + decisionEffect;

        GUIStyle myStyle = new GUIStyle();
        myStyle.fontSize = 35;
        myStyle.normal.textColor = Color.white;

        if (trust == 0) {
            showTrust = !showTrust;
            LosePanel.gameObject.SetActive(true);
            showStats.hideText();
            Time.timeScale = 0;
        }

        if (showTrust) {
            if (trust > 100)
                GUI.Label(new Rect(220, 35, 200, 20), "Trust: 100%", myStyle);
            else
                GUI.Label(new Rect(220, 35, 200, 20), "Trust: " + trust.ToString() + "%", myStyle);
        }
    }
    public void addTrust(int amount){
        trust += amount;
    }
    public void loseTrust(int amount){
        trust -= amount;
    }

    public void showTrustText()
    {
        showTrust = true;
    }

    public void hideTrustText()
    {
        showTrust = false;
    }
    public void makeDecision(bool yes){
        if (yes)
            decisionEffect -= 5;
        else   
            decisionEffect += 5;
    }
}
