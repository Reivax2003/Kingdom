﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckSelected : MonoBehaviour
{
    private string humanName = "Person(Clone)";
    public GameObject groupManager;
    public Material Normal;
    public Material Selected;

    // Start is called before the first frame update
    void Start(){
        groupManager = GameObject.Find("PEOPLE MANAGER");
    }
    void OnTriggerEnter(Collider other){
        if (other.transform.name == humanName){
            GameObject newGuy = other.gameObject;
            newGuy.GetComponent<Renderer>().material = Selected;
            groupManager.SendMessage("addToGroup", newGuy);
        }
    }
    void OnTriggerExit(Collider other){
        if (other.transform.name == humanName){
            GameObject newGuy = other.gameObject;
            newGuy.SendMessage("GoToNormal");
            groupManager.SendMessage("removeFromGroup", newGuy);
        }
    }
}