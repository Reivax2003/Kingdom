﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class DoStuff : MonoBehaviour
{

    public bool isBreaking = false;
    public GameObject resource;
    public Material normal;
    // Update is called once per frame
    void Update()
    {
        if (isBreaking==true){
           
                if (Mathf.Abs(resource.transform.position.x-transform.position.x) <= 3 && Mathf.Abs(resource.transform.position.z-transform.position.z) <= 3){
                    TrackProgress script = resource.GetComponent<TrackProgress>();
                    resource.SendMessage("takeDamage", 1*Time.deltaTime);
                    if (script.isDead)
                        resource = null;
                }
           
        }
    }
    void moveAndBreak(GameObject res){
        if (resource != null)
            resource.SendMessage("stopTask");

        isBreaking = true;
        resource = res;
    }
    void GoToNormal(){
        transform.GetComponent<Renderer>().material = normal;
    }
    
}
