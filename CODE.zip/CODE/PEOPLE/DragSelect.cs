﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.AI;

public class DragSelect : MonoBehaviour
{
    public List<GameObject> group;
    public Vector3 startLoc;
    public Vector3 endLoc;
    public GameObject box;
    private GameObject selectedArea = null;
    private PlaceThing script;

    // Update is called once per frame
    void Start(){
        script = Camera.main.GetComponent<PlaceThing>();
    }
    void Update()
    {
        if (EventSystem.current.IsPointerOverGameObject())
        {
            //Debug.Log("Over UI");
        }
        else if (Input.GetMouseButton(1)){
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (group.Count > 0 && Physics.Raycast(ray, out hit)){
                if (hit.transform.name == "Fir_Tree(Clone)" || hit.transform.name == "Rock1(Clone)" || hit.transform.name == "CowBlW(Clone)" || hit.transform.name == "ChickenBrown(Clone)" || hit.transform.name == "DuckWhite(Clone)" || hit.transform.name == "Pig(Clone)" || hit.transform.name == "SheepWhite(Clone)"){
                    for(int i = 0; i < group.Count; i++){
                        NavMeshAgent agent = group[i].gameObject.GetComponent<NavMeshAgent>();
                        agent.SetDestination(hit.point);

                        group[i].SendMessage("moveAndBreak", hit.transform.gameObject);
                    }
                }
                else{
                    for(int i = 0; i < group.Count; i++){
                        NavMeshAgent agent = group[i].gameObject.GetComponent<NavMeshAgent>();
                        agent.SetDestination(hit.point);
                    }
                }
            }
            
        }
        if (EventSystem.current.IsPointerOverGameObject())
        {
            //Debug.Log("Over UI");
        }
        else if (Input.GetMouseButtonDown(0) && script.currentBuilding == null){
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, 1000))
                startLoc = hit.point;

            selectedArea = Instantiate(box, hit.point, Quaternion.identity);
            selectedArea.transform.localScale = new Vector3(0f, 5f, 0f);
            selectedArea.layer = 2;

            for(int i = 0; i < group.Count; i++){
                group[i].SendMessage("GoToNormal");
            }

            group = new List<GameObject>();
        }
        else if (Input.GetMouseButton(0) && selectedArea != null  && script.currentBuilding == null){
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit, 1000))
                endLoc = hit.point;

            selectedArea.transform.position = new Vector3(startLoc.x+(endLoc.x-startLoc.x)/2, 2, startLoc.z+(endLoc.z-startLoc.z)/2);
            selectedArea.transform.localScale = new Vector3(startLoc.x-endLoc.x, 5f, startLoc.z-endLoc.z);
        }

        if (Input.GetMouseButtonUp(0)){
            Destroy(selectedArea);
            selectedArea = null;
        }
    }
    void addToGroup(GameObject newGuy){
        group.Add(newGuy);
    }
    void removeFromGroup(GameObject newGuy){
        group.Remove(newGuy);
    }
}
