﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreatePeople : MonoBehaviour
{
    public GameObject personModel;
    public GameObject resourceManager;
    public GameObject peopleManager;

    public void summonPerson(GameObject home){
        Instantiate(personModel, home.transform.position+new Vector3(-12, 0, 0), Quaternion.identity, peopleManager.transform);
        resourceManager.SendMessage("addAmount", new int[2]{3, 1});
    }
}
