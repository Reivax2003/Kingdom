﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class BuildingInfo : MonoBehaviour {
    private bool canPlace = true;
    private bool canMove = false;
    private GameObject ghost = null;
    private Transform[] ts;

    public AudioSource buildingSound;
    public BuildingStats script;
    public Button des;
    public Button up;
    public float yPos = 1f;
    public GameObject currentBuilding;
    public GameObject InfoPanel;
    public GameObject parent;
    public GameObject resourceHolder;
    public HappinessMeter happy;
    public Material ghostMaterial, CantPlace;
    public PlaceThing placeThing;
    public Text HP;
    public Text Info;
    public Text textLevel;
    public Text CantBuy;
    public TrustMeter trust;

    int rotationcounter = 1;

    void Update() {
        if (canMove) {
            InfoPanel.gameObject.SetActive(false);

            if (Input.GetMouseButtonDown(0)) {
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;

                if (Physics.Raycast(ray, out hit, 1000) && Input.mousePosition.y > 30 && canPlace) {
                    currentBuilding.transform.position = new Vector3(hit.point.x, hit.transform.position.y + hit.transform.localScale.y / 4 + (currentBuilding.transform.lossyScale.y / 2), hit.point.z);
     
                    if (!Input.GetKey(KeyCode.LeftShift))
                        rotationcounter = 1;

                    canMove = false;
                    Destroy(ghost);
                }
            } else {
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;

                if (Physics.Raycast(ray, out hit, 1000) && Input.mousePosition.y > 30) {
                    if (ghost == null) {
                        ghost = Instantiate(currentBuilding, new Vector3(hit.point.x, hit.transform.position.y + hit.transform.localScale.y / 4 + (currentBuilding.transform.localScale.y / 2), hit.point.z) , Quaternion.identity, parent.transform);
                        ghost.name = "ghost";
                        ghost.GetComponent<Renderer>().material = ghostMaterial;
                        ghost.layer = 2;

                        if (!canPlace)
                            ghost.GetComponent<Renderer>().material = CantPlace;

                        ts = ghost.GetComponentsInChildren<Transform>();

                        for (int i = 0; i < ts.Length; i++)
                            ts[i].GetComponent<Renderer>().material = ghost.GetComponent<Renderer>().material;

                        Debug.Log(ghost.transform.position);
                    } else {
                        ghost.GetComponent<Renderer>().material = ghostMaterial;
                        ghost.layer = 2;

                        if (Input.GetKeyDown("z")) {
                            ghost.transform.Rotate(0, 45, 0, relativeTo: Space.Self);
                            rotationcounter++;
                        }

                        if (Input.GetKeyDown("x")) {
                            ghost.transform.Rotate(0, -45, 0, relativeTo: Space.Self);
                            rotationcounter--;
                        }

                        if (!canPlace)
                            ghost.GetComponent<Renderer>().material = CantPlace;

                        for (int i = 0; i < ts.Length; i++)
                            ts[i].GetComponent<Renderer>().material = ghost.GetComponent<Renderer>().material;

                        ghost.transform.position = new Vector3(hit.point.x, hit.transform.position.y + hit.transform.localScale.y / 4 + (currentBuilding.transform.localScale.y / 2), hit.point.z);
                    }
                }
            }

            if (Input.GetMouseButtonDown(1)) {
                canMove = false;
                Destroy(ghost);
            }
        } else {
            if (Input.GetMouseButtonDown(1)) {
                RaycastHit hit;
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

                if (Physics.Raycast(ray, out hit)) {
                    if (hit.collider.gameObject.name == "Castle(Clone)" ||
                        hit.collider.gameObject.name == "House_Stone_2(Clone)" ||
                        hit.collider.gameObject.name == "Church(Clone)" ||
                        hit.collider.gameObject.name == "Warehouse(Clone)" ||
                        hit.collider.gameObject.name == "House_Wood_1(Clone)" ||
                        hit.collider.gameObject.name == "Shop(Clone)" ||
                        hit.collider.gameObject.name == "Carpet_shop(Clone)" ||
                        hit.collider.gameObject.name == "Small Tent 1(Clone)" ||
                        hit.collider.gameObject.name == "Cannon(Clone)" ||
                        hit.collider.gameObject.name == "Barricade 1(Clone)" ||
                        hit.collider.gameObject.name == "Farm_wheat_7(Clone)" ||
                        hit.collider.gameObject.name == "Fence_1(Clone)" ||
                        hit.collider.gameObject.name == "Lantern_1(Clone)" ||
                        hit.collider.gameObject.name == "Road_1(Clone)")
                    {

                        currentBuilding = hit.collider.gameObject;

                        script = hit.collider.gameObject.GetComponent<BuildingStats>();

                        textLevel.text = "Level: " + script.thisLevel.ToString();
                        HP.text = "HP: " + script.thisCurrentHP.ToString() + "/" + script.thisTotalHP.ToString();

                        CantBuy.gameObject.SetActive(false);

                        if (script.thisLevel == 5) {
                            Info.text = "Max Level!";
                            up.gameObject.SetActive(false);
                        } else {
                            Info.text = "Next upgrade: " + (script.totalHP * script.thisLevel * 2) + " Gold, " + (script.totalHP * script.thisLevel) + " Wood, " + (script.totalHP * script.thisLevel) + " Stone";
                            up.gameObject.SetActive(true);
                        }

                        if (hit.collider.gameObject.name == "Castle(Clone)") {
                            des.gameObject.SetActive(false);
                        } else {
                            des.gameObject.SetActive(true);
                        }

                        InfoPanel.gameObject.SetActive(true);
                    }
                }
            }
        }
    }
    
    public void Cancel() {
        InfoPanel.gameObject.SetActive(false);
    }

    public void Upgrade() {
        int[] currentAmount = resourceHolder.GetComponent<ResourceManager>().amount;
        int goldPrice = script.totalHP * script.thisLevel * 2;
        int woodPrice = script.totalHP * script.thisLevel;
        int stonePrice = script.totalHP* script.thisLevel;

        if (goldPrice <= currentAmount[0] && woodPrice <= currentAmount[1] && stonePrice <= currentAmount[5]) {
            resourceHolder.SendMessage("spendAmount", new int[2] { 0, goldPrice});
            resourceHolder.SendMessage("spendAmount", new int[2] { 1, woodPrice });
            resourceHolder.SendMessage("spendAmount", new int[2] { 5, stonePrice });

            if (script.thisLevel < 5) {
                script.thisLevel++;
                script.thisCurrentHP *= 5;
                script.thisTotalHP *= 5;

                textLevel.text = "Level: " + script.thisLevel.ToString();
                HP.text = "HP: " + script.thisCurrentHP.ToString() + "/" + script.thisTotalHP.ToString();

                if (script.thisLevel == 5) {
                    Info.text = "Max Level!";
                    up.gameObject.SetActive(false);
                } else {
                    Info.text = "Next upgrade: " + (script.totalHP * script.thisLevel * 2) + " Gold, " + (script.totalHP * script.thisLevel) + " Wood, " + (script.totalHP * script.thisLevel) + " Stone";
                    up.gameObject.SetActive(true);
                }

                buildingSound.Play(0);
            }
        } else {
            CantBuy.gameObject.SetActive(true);
        }
    }

    public void DestroyBuilding() {
        InfoPanel.gameObject.SetActive(false);
        Destroy(currentBuilding);

        string[] Order = new string[13] { "House_Stone_2(Clone)", "Church(Clone)", "Warehouse(Clone)", "House_Wood_1(Clone)",
                                       "Shop(Clone)", "Carpet_shop(Clone)", "Small Tent 1(Clone)", "Cannon(Clone)",
                                       "Barricade 1(Clone)", "Farm_wheat_7(Clone)", "Fence_1(Clone)", "Lantern_1(Clone)",
                                       "Road_1(Clone)" };
        int[] currentAmount = resourceHolder.GetComponent<ResourceManager>().amount;
        int[][] buildingPrices = placeThing.GetComponent<PlaceThing>().prices;
        int index = -1;
      
        for (int i = 0; i < Order.Length; i++) {
            if (Order[i] == currentBuilding.name) {
                index = i;

                if (index == 0) {
                    placeThing.Houses--;
                } else if (index == 1) {
                    placeThing.Churches--;
                } else if (index == 2) {
                    placeThing.Storages--;
                } else if (index == 3) {
                    placeThing.Bars--;
                } else if (index == 4) {
                    placeThing.RoadShops--;
                } else if (index == 5) {
                    placeThing.CarpetShops--;
                } else if (index == 6) {
                    placeThing.Armories--;
                } else if (index == 7) {
                    placeThing.Cannons--;
                } else if (index == 8) {
                    placeThing.Walls--;
                } else if (index == 9) {
                    placeThing.Farms--;
                } else if (index == 10) {
                    placeThing.Fences--;
                } else if (index == 11) {
                    placeThing.Lanterns--;
                } else if (index == 12) {
                    placeThing.Roads--;
                }
            }
        }

        for (int i = 0; i < currentAmount.Length; i++) {
            currentAmount[i] += Mathf.RoundToInt(buildingPrices[index + 1][i] / 2);
        }
    }

    public void Move() {
        canMove = true;
        canPlace = true;
    }

    private void intersecting() {
        canPlace = false;
    }

    private void nonIntersecting() {
        canPlace = true;
    }
}
