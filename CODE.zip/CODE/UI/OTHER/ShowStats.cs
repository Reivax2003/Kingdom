﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShowStats : MonoBehaviour
{
    public GameObject StatHolder;
    public int[] all;
    public string[] order;
    public ResourceManager script;
    public bool showhideText = true;

    void Start(){
        script = StatHolder.GetComponent<ResourceManager>();
        all = script.amount;
        order = script.order;
    }
    void OnGUI(){
        all = script.amount;

        GUIStyle myStyle = new GUIStyle();
        myStyle.fontSize = 35;
        myStyle.normal.textColor = Color.white;

        if (showhideText) {
            for (int i = 0; i < all.Length; i++)
                GUI.Label(new Rect(10, i * 35, 200, 20), order[i] + ": " + all[i].ToString(), myStyle);
        }
    }

    public void showText() {
        showhideText = true;
    }

    public void hideText() {
        showhideText = false;
    }
}
