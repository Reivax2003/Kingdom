﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildingStats : MonoBehaviour {
    public int Level;
    public int currentHP;
    public int totalHP;

    public int thisLevel;
    public int thisCurrentHP;
    public int thisTotalHP;

    void Start() {
        thisLevel = Level;
        thisCurrentHP = currentHP;
        thisTotalHP = totalHP;
    }
}
