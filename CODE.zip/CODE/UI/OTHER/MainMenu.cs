﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour {
    public GameObject mainMenu;
    public GameObject instructions;
    public Button pauseButton;
    public ShowStats stats;
    public HappinessMeter happy;
    public TrustMeter trust;
    public GameObject LosePanel;
    public Check pop;

    void Start() {
        mainMenu.gameObject.SetActive(true);
        pauseButton.gameObject.SetActive(false);
        stats.hideText();
        happy.hideHappText();
        trust.hideTrustText();
        LosePanel.gameObject.SetActive(false);
        pop.playing = false;
        Time.timeScale = 0;
    }

    public void Play() {
        mainMenu.gameObject.SetActive(false);
        pauseButton.gameObject.SetActive(true);
        stats.showText();
        happy.showHappText();
        trust.showTrustText();
        pop.playing = true;
        Time.timeScale = 1;
    }
}
