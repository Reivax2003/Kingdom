﻿using System.Collections;
using UnityEngine;

public class HideInfoPanel : MonoBehaviour {
    public GameObject InfoPanel;

    void Start() {
        InfoPanel.gameObject.SetActive(false);
    }
}
