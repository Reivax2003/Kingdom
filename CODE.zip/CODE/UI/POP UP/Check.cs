﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class Check : MonoBehaviour
{

    public PopUp window;
    public ResourceManager Resources;
    public HappinessMeter happiness;
    public PlaceThing placeThing;
    public TrustMeter trust;
    public CreatePeople peoples;
    public GameObject mainBuilding;
    private UnityAction Yes;
    private UnityAction No;
    private UnityAction Cancel;
    string Famine;
    string Stranger;
    string Plague;
    string Locusts;
    string Poverty;
    string Sim;
    string RoundEarth;
    string Crime;
    string Conspiracy;
    string Enemy;
    string Protest;
    public bool playing;
    public int choice;

    void Awake()
    {
        window = PopUp.Instance();

    }
    void Update()
    {
        if (Time.frameCount%2000==0)
        {
            TimedTest();
        }
    }
    void TimedTest()
    {
        Famine = "Your people are starving, we can try to implement an alternative food source.";
        Stranger = "An outsider came to you kingdom, we can accept the outsider as one of our villagers.";
        Plague = "The plague has been spreading, we can get rid of all of the infected people.";
        Locusts = "There has been a swarm of locusts in your kingdom, we can get rid of some crops.";
        Poverty = "Poverty rates have increased, we can increase people's salaries";
        Sim = "A villiger is starting to become aware of its existance and is trying to spread the word that they're in a simulation, we can take him out";
        RoundEarth = "A villiger is trying to teach kids that the Earth is actually round and not flat, we can take him out";
        Crime = "Crime rates have increased, we can start a tax on stronger protection";
        Conspiracy = "A villiger has started a conspiracy that the government is controling everybody, we can take him out before he becomes more aware of the truth.";
        Enemy = "A nearby kingdom is threatening to destroy your kingdom, we can fight them";
        Protest = "The villigers are not happy with the way your running the kingdom and they plan on taking down the government, we can give everybody gifts";

        if (playing)
        {
            int[] currentAmount = Resources.GetComponent<ResourceManager>().amount;

            if (currentAmount[3] > 1) {
                if (currentAmount[2] <= 10 && currentAmount[3] > 10)
                {
                    choice = 1;
                    window.Choice(Famine, window.Icon, TestYes, TestNo);
                }
                else if (currentAmount[0] > 1000 && currentAmount[3] > 50)
                {
                    choice = 2;
                    window.Choice(Stranger, window.Icon, TestYes, TestNo);
                }
                else if (placeThing.Houses > 50)
                {
                    choice = 3;
                    window.Choice(Plague, window.Icon, TestYes, TestNo);
                }
                else if (currentAmount[2] > 100 && placeThing.Storages > 5 && placeThing.Farms > 5)
                {
                    choice = 4;
                    window.Choice(Locusts, window.Icon, TestYes, TestNo);
                }
                else if (currentAmount[0] <= 50 && currentAmount[3] > 10)
                {
                    choice = 5;
                    window.Choice(Poverty, window.Icon, TestYes, TestNo);
                }
                else if (happiness.happiness == 100)
                {
                    choice = 6;
                    window.Choice(Sim, window.Icon, TestYes, TestNo);
                }
                else if (placeThing.Churches > 10)
                {
                    choice = 7;
                    window.Choice(RoundEarth, window.Icon, TestYes, TestNo);
                }
                else if (currentAmount[0] < 100 && currentAmount[2] < 50 && currentAmount[3] > 25)
                {
                    choice = 8;
                    window.Choice(Crime, window.Icon, TestYes, TestNo);
                }
                else if (trust.trust == 100)
                {
                    choice = 9;
                    window.Choice(Conspiracy, window.Icon, TestYes, TestNo);
                }
                else if (currentAmount[0] > 1000 && currentAmount[1] > 500 && currentAmount[2] > 750 && currentAmount[3] > 100 && currentAmount[4] > 500 && currentAmount[5] > 500)
                {
                    choice = 10;
                    window.Choice(Enemy, window.Icon, TestYes, TestNo);
                }
                else if (happiness.happiness < 50 && trust.trust < 50)
                {
                    choice = 11;
                    window.Choice(Protest, window.Icon, TestYes, TestNo);
                }
            }
        }
    }
    void TestCancel()
    {
        Debug.Log("Closed");
    }
    void TestYes()
    {
        int[] currentAmount = Resources.GetComponent<ResourceManager>().amount;

        if (choice == 1) {
            happiness.makeDecision(false);
            currentAmount[2] += 25;
            currentAmount[3] -= 5;

            for (int x = 0; x < 5; x++)
                Destroy(GameObject.Find("GAME MANAGER/PEOPLE MANAGER/Person(Clone)"));
        } else if (choice == 2) {
            trust.makeDecision(true);
            currentAmount[0] += 10;
            currentAmount[3]++;
            peoples.summonPerson(mainBuilding);
        } else if (choice == 3) {
            for (int x = 0; x < 2; x++)
                happiness.makeDecision(true);

            currentAmount[3] -= 10;

            for (int x = 0; x < 10; x++)
                Destroy(GameObject.Find("GAME MANAGER/PEOPLE MANAGER/Person(Clone)"));
        } else if (choice == 4) {
            for (int x = 0; x < 2; x++)
                happiness.makeDecision(true);

            currentAmount[2] -= 50;
        } else if (choice == 5) {
            for (int x = 0; x < 2; x++)
                happiness.makeDecision(false);

            currentAmount[0] = 0;
        } else if (choice == 6) {
            for (int x = 0; x < 2; x++)
                trust.makeDecision(true);

            currentAmount[3]--;
            Destroy(GameObject.Find("GAME MANAGER/PEOPLE MANAGER/Person(Clone)"));
        } else if (choice == 7) {
            for (int x = 0; x < 2; x++)
                trust.makeDecision(true);

            currentAmount[3]--;
            Destroy(GameObject.Find("GAME MANAGER/PEOPLE MANAGER/Person(Clone)"));
        } else if (choice == 8) {
            for (int x = 0; x < 2; x++) {
                happiness.makeDecision(true);
                trust.makeDecision(true);
            }

            currentAmount[0] += 100;
            currentAmount[1] -= 100;
            currentAmount[4] -= 100;
            currentAmount[5] -= 100;
        } else if (choice == 9) {
            for (int x = 0; x < 2; x++)
                trust.makeDecision(true);

            currentAmount[3]--;
            Destroy(GameObject.Find("GAME MANAGER/PEOPLE MANAGER/Person(Clone)"));
        } else if (choice == 10) {
            int win = Random.Range(0, 1);

            for (int x = 0; x < 6; x++) {
                int val = Random.Range(-1000, 1000);

                if (x == 3) {
                    if (val < 100) {
                        val = -100;
                    }

                    for (int i = 0; i < val; i++)
                        Destroy(GameObject.Find("GAME MANAGER/PEOPLE MANAGER/Person(Clone)"));
                } else {
                    currentAmount[x] = currentAmount[x] + val;
                }
            }

            if (win == 0) {
                for (int x = 0; x < 5; x++) {
                    happiness.makeDecision(true);
                    trust.makeDecision(true);
                }
            } else if (win == 1) {
                happiness.happiness = 100;
                trust.trust = 100;
            }
        } else if (choice == 11) {
            happiness.makeDecision(false);
            trust.makeDecision(false);
            currentAmount[0] = 0;
        }
    } 

    void TestNo()
    {
        int[] currentAmount = Resources.GetComponent<ResourceManager>().amount;

        if (choice == 1) {
            for (int x = 0; x < 3; x++) 
                happiness.makeDecision(true);

            currentAmount[2] = 0;
            currentAmount[3] -= 10;

            for (int x = 0; x < 10; x++)
                Destroy(GameObject.Find("GAME MANAGER/PEOPLE MANAGER/Person(Clone)"));
        } else if (choice == 3) {
            happiness.makeDecision(true);
            trust.makeDecision(true);
            currentAmount[3] -= 20;

            for (int x = 0; x < 20; x++)
                Destroy(GameObject.Find("GAME MANAGER/PEOPLE MANAGER/Person(Clone)"));
        } else if (choice == 4) {
            happiness.makeDecision(true);
            trust.makeDecision(true);
            currentAmount[2] -= 100;
        } else if (choice == 5) {
            for (int x = 0; x < 3; x++)
                happiness.makeDecision(true);
        } else if (choice == 6) {
            for (int x = 0; x < 3; x++)
                trust.makeDecision(true);
        } else if (choice == 7) {
            for (int x = 0; x < 3; x++)
                trust.makeDecision(true);
        } else if (choice == 8) {
            happiness.makeDecision(true);
            trust.makeDecision(true);
            currentAmount[0] -= 100;
            currentAmount[2] -= 50;
            currentAmount[3] -= 5;

            for (int x = 0; x < 5; x++)
                Destroy(GameObject.Find("GAME MANAGER/PEOPLE MANAGER/Person(Clone)"));
        } else if (choice == 9) {
            for (int x = 0; x < 3; x++)
                trust.makeDecision(true);
        } else if (choice == 10) {
            for (int x = 0; x < 5; x++)
                happiness.makeDecision(true);
            currentAmount[0] -= 500;
            currentAmount[1] -= 250;
            currentAmount[2] -= 375;
            currentAmount[3] -= 50;

            for (int x = 0; x < 50; x++)
                Destroy(GameObject.Find("GAME MANAGER/PEOPLE MANAGER/Person(Clone)"));

            currentAmount[4] -= 250;
            currentAmount[5] -= 250;
        } else if (choice == 11) {
            for (int x = 0; x < 4; x++) {
                happiness.makeDecision(true);
                trust.makeDecision(true);
            }
        }
    }

} 