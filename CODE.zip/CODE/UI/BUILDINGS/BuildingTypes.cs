﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildingTypes : MonoBehaviour {
    public GameObject Back;
    public GameObject MainBuilding;
    public GameObject Buildings, House, Church, Storage, Bar, RoadShop, CarpetShop;
    public GameObject Armory, ArmyBase, Cannon, Wall;
    public GameObject Farm, Field, Fence;
    public GameObject Decorations, Lantern, Road;

    void Start() {
        Back.gameObject.SetActive(false);

        Buildings.gameObject.SetActive(false);
        Armory.gameObject.SetActive(false);
        Farm.gameObject.SetActive(false);
        Decorations.gameObject.SetActive(false);

        gone();
    }

    public void Appear() {
        MainBuilding.gameObject.SetActive(false);
        Back.gameObject.SetActive(false);
        Buildings.gameObject.SetActive(true);
        Armory.gameObject.SetActive(true);
        Farm.gameObject.SetActive(true);
        Decorations.gameObject.SetActive(true);
    }

    void disappear() {
        Back.gameObject.SetActive(true);

        Buildings.gameObject.SetActive(false);
        Armory.gameObject.SetActive(false);
        Farm.gameObject.SetActive(false);
        Decorations.gameObject.SetActive(false);
    }

    void gone() {
        House.gameObject.SetActive(false);
        Church.gameObject.SetActive(false);
        Storage.gameObject.SetActive(false);
        Bar.gameObject.SetActive(false);
        RoadShop.gameObject.SetActive(false);
        CarpetShop.gameObject.SetActive(false);

        ArmyBase.gameObject.SetActive(false);
        Cannon.gameObject.SetActive(false);
        Wall.gameObject.SetActive(false);

        Field.gameObject.SetActive(false);
        Fence.gameObject.SetActive(false);

        Lantern.gameObject.SetActive(false);
        Road.gameObject.SetActive(false);
    }

    public void BackButton() {
        Appear();
        gone();
    }

    public void BuildingsButton() {
        disappear();

        House.gameObject.SetActive(true);
        Church.gameObject.SetActive(true);
        Storage.gameObject.SetActive(true);
        Bar.gameObject.SetActive(true);
        RoadShop.gameObject.SetActive(true);
        CarpetShop.gameObject.SetActive(true);
    }

    public void ArmoryButton() {
        disappear();

        ArmyBase.gameObject.SetActive(true);
        Cannon.gameObject.SetActive(true);
        Wall.gameObject.SetActive(true);
    }

    public void FarmButton() {
        disappear();

        Field.gameObject.SetActive(true);
        Fence.gameObject.SetActive(true);
    }

    public void DecorationsButton() {
        disappear();

        Lantern.gameObject.SetActive(true);
        Road.gameObject.SetActive(true);
    }
}
