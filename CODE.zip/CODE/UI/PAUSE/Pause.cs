﻿using System.Collections;
using UnityEngine;

public class Pause : MonoBehaviour {
    public GameObject Pause_Panel, Pause_Menu_Panel, Music_Sound_Panel, Button_Panel;
    public GameObject mainMenu;
    public Check pop;

    public void Start() {
        showhidePanel();
    }

    public void pauseIt() {
        Pause_Panel.gameObject.SetActive(true);
        Pause_Menu_Panel.gameObject.SetActive(true);
        Music_Sound_Panel.gameObject.SetActive(true);
        Button_Panel.gameObject.SetActive(true);
        pop.playing = false;
        Time.timeScale = 0;
    }

    public void showhidePanel() {
        Pause_Panel.gameObject.SetActive(false);
        Pause_Menu_Panel.gameObject.SetActive(false);
        Music_Sound_Panel.gameObject.SetActive(false);
        Button_Panel.gameObject.SetActive(false);
        pop.playing = true;
        Time.timeScale = 1;
    }
}
