﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Help_Instructions : MonoBehaviour {
    public GameObject HelpCreditsPanel;
    public GameObject PauseButtonPanel;
    public Text instructions;
    public Text credits;

    void Start() {
        HelpCreditsPanel.gameObject.SetActive(false);
    }

    public void NeedHelp() {
        Hide();
        instructions.text = "Controls:\n" +
        	        "Left Click: Setting buildings down, selecting items\n" +
        	        "Right Click (on buildings): Getting building info\n" +
                    "Right Click (on objects when people are selected): Sending people to destroy that object\n" +
        	        "Wheel Button: Zooming\n" +
        	        "Z Key: Rotate buildings to the left\n" +
        	        "X Key: Rotate buildings to the right\n" +
        	        "Holding Left Shift: Setting same building down\n" +
                    "Holding Left Click: Drag select people\n";
        credits.text = "";
    }

    public void Credits() {
        Hide();
        instructions.text = "";
        credits.text = "Credits:\n" +
        	           "Area 51 aliens";
    }

    public void Hide() {
        HelpCreditsPanel.gameObject.SetActive(true);
    }

    public void hideHelpCredits() {
        HelpCreditsPanel.gameObject.SetActive(false);
    }
}
