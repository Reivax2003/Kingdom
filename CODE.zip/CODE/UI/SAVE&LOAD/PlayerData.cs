﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerData{
    public float[,] City;
    public string[] prefabs;
    public string[] resPrefabs;
    public float[,] Resources;
    public int Houses, Churches, Storages, Bars, RoadShops, CarpetShops, Armories, Cannons, Walls, Farms, Fences, Lanterns, Roads;
    public int Gold, Wood, Food, Population, Metal, Stone;
    public PlayerData (Player player)
    {
        GameObject CityHolder = player.GetComponent<Player>().City;
        GameObject ResourceHolder = player.GetComponent<Player>().Resource;
        City = new float[CityHolder.transform.childCount, 6];
        prefabs = new string[CityHolder.transform.childCount];
        for(int i = 0; i < CityHolder.transform.childCount; i++){
            prefabs[i] = CityHolder.transform.GetChild(i).name.Substring(0, CityHolder.transform.GetChild(i).name.Length-7);
            City[i, 0] = CityHolder.transform.GetChild(i).position.x;
            City[i, 1] = CityHolder.transform.GetChild(i).position.y;
            City[i, 2] = CityHolder.transform.GetChild(i).position.z;
            City[i, 3] = CityHolder.transform.GetChild(i).rotation.y;
            City[i, 4] = CityHolder.transform.GetChild(i).GetComponent<BuildingStats>().Level;
            City[i, 5] = CityHolder.transform.GetChild(i).GetComponent<BuildingStats>().currentHP;
        }
        Houses = Camera.main.GetComponent<PlaceThing>().Houses;
        Churches = Camera.main.GetComponent<PlaceThing>().Churches;
        Storages = Camera.main.GetComponent<PlaceThing>().Storages;
        Bars = Camera.main.GetComponent<PlaceThing>().Bars;
        RoadShops = Camera.main.GetComponent<PlaceThing>().RoadShops;
        CarpetShops = Camera.main.GetComponent<PlaceThing>().CarpetShops;
        Armories = Camera.main.GetComponent<PlaceThing>().Armories;
        Cannons = Camera.main.GetComponent<PlaceThing>().Cannons;
        Walls = Camera.main.GetComponent<PlaceThing>().Walls;
        Fences = Camera.main.GetComponent<PlaceThing>().Fences;
        Lanterns = Camera.main.GetComponent<PlaceThing>().Lanterns;
        Roads = Camera.main.GetComponent<PlaceThing>().Roads;
        Farms = Camera.main.GetComponent<PlaceThing>().Farms;

        Gold = ResourceHolder.GetComponent<ResourceManager>().Gold;
        Wood = ResourceHolder.GetComponent<ResourceManager>().Wood;
        Metal = ResourceHolder.GetComponent<ResourceManager>().Metal;
        Food = ResourceHolder.GetComponent<ResourceManager>().Food;
        Stone = ResourceHolder.GetComponent<ResourceManager>().Stone;

        Resources = new float[ResourceHolder.transform.childCount, 5];
        resPrefabs = new string[ResourceHolder.transform.childCount];
        for(int i = 0; i < ResourceHolder.transform.childCount; i++){
            resPrefabs[i] = ResourceHolder.transform.GetChild(i).name.Substring(0, ResourceHolder.transform.GetChild(i).name.Length-7);
            Resources[i, 0] = ResourceHolder.transform.GetChild(i).transform.position.x;
            Resources[i, 1] = ResourceHolder.transform.GetChild(i).transform.position.y;
            Resources[i, 2] = ResourceHolder.transform.GetChild(i).transform.position.z;
            Resources[i, 3] = ResourceHolder.transform.GetChild(i).GetComponent<TrackProgress>().currentHp;
            Resources[i, 4] = (float) ResourceHolder.transform.GetChild(i).GetComponent<TrackProgress>().deaths;
        }
    }
}
