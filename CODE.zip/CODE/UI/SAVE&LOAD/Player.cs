﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {
    public GameObject Resource;
    public GameObject City;

    public void SaveSystem(){
        SavePlayer.SaveFile(this);
    }
    public void LoadSystem(){
        PlayerData data = SavePlayer.LoadPlayer();
        GameObject peopleHolder = GameObject.Find("PEOPLE MANAGER");
        GameObject resourceHolder = GameObject.Find("RESOURCE MANAGER");

        Debug.Log(data.City.Length/6);
        for (int x = 0; x < data.City.Length/6; x++){
            GameObject newBuild = (GameObject) Instantiate(Resources.Load(data.prefabs[x]), new Vector3(data.City[x, 0], data.City[x, 1], data.City[x, 2]), new Quaternion(0,data.City[x, 3], 0, 0), GameObject.Find("CITY HOLDER").transform);

            newBuild.GetComponent<BuildingStats>().Level = (int) data.City[x, 4];
            newBuild.GetComponent<BuildingStats>().currentHP = (int) data.City[x, 5];

            GameObject currentBuilding = newBuild;
            currentBuilding.name = currentBuilding.name.Substring(0, currentBuilding.name.Length-7);
            
            //Debug.Log(currentBuilding.name);
            //Debug.Log(Camera.main.GetComponent<PlaceThing>().MainBuilding.name);
            if (currentBuilding.name == Camera.main.GetComponent<PlaceThing>().MainBuilding.name) {
                for (int i = 0; i < 5; i++)
                    peopleHolder.SendMessage("summonPerson", newBuild);
                Camera.main.GetComponent<BuildingTypes>().Appear();
            } 
            else if (currentBuilding.name == Camera.main.GetComponent<PlaceThing>().House.name){
                for (int i = 0; i < 2; i++)
                    peopleHolder.SendMessage("summonPerson", newBuild);
                Camera.main.GetComponent<PlaceThing>().Houses++;
            } 
            else if (currentBuilding.name == Camera.main.GetComponent<PlaceThing>().Farm.name){
                Camera.main.GetComponent<PlaceThing>().Farms++;
            } 
            else if (currentBuilding.name == Camera.main.GetComponent<PlaceThing>().Storage.name){
                resourceHolder.SendMessage("addMax");
                Camera.main.GetComponent<PlaceThing>().Storages++;
            }
            else if (currentBuilding.name == Camera.main.GetComponent<PlaceThing>().Bar.name){
                Camera.main.GetComponent<PlaceThing>().Bars++;
            }
            else if (currentBuilding.name == Camera.main.GetComponent<PlaceThing>().Church.name){
                Camera.main.GetComponent<PlaceThing>().Churches++;
            }
            else if (currentBuilding.name == Camera.main.GetComponent<PlaceThing>().Armory.name){
                Camera.main.GetComponent<PlaceThing>().Armories++;
            }
            else if (currentBuilding.name == Camera.main.GetComponent<PlaceThing>().RoadShop.name){
                Camera.main.GetComponent<PlaceThing>().RoadShops++;
            }
            else if (currentBuilding.name == Camera.main.GetComponent<PlaceThing>().CarpetShop.name){
                Camera.main.GetComponent<PlaceThing>().CarpetShops++;
            }
            else if (currentBuilding.name == Camera.main.GetComponent<PlaceThing>().Cannon.name){
                Camera.main.GetComponent<PlaceThing>().Cannons++;
            }
            else if (currentBuilding.name == Camera.main.GetComponent<PlaceThing>().Wall.name){
                Camera.main.GetComponent<PlaceThing>().Walls++;
            }
            else if (currentBuilding.name == Camera.main.GetComponent<PlaceThing>().Fence.name){
                Camera.main.GetComponent<PlaceThing>().Fences++;
            }
            else if (currentBuilding.name == Camera.main.GetComponent<PlaceThing>().Farm.name){
                Camera.main.GetComponent<PlaceThing>().Farms++;
            }
        }
        resourceHolder.GetComponent<ResourceManager>().Gold = data.Gold;
        resourceHolder.GetComponent<ResourceManager>().Wood = data.Wood;
        resourceHolder.GetComponent<ResourceManager>().Metal = data.Metal;
        resourceHolder.GetComponent<ResourceManager>().Food = data.Food;
        resourceHolder.GetComponent<ResourceManager>().Stone = data.Stone;

        foreach (Transform child in resourceHolder.transform) {
            GameObject.Destroy(child.gameObject);
        }

        for (int i = 0; i < data.Resources.Length/5; i++){
            GameObject newBuild = (GameObject) Instantiate(Resources.Load(data.resPrefabs[i]), new Vector3(data.Resources[i, 0], data.Resources[i, 1], data.Resources[i, 2]), Quaternion.identity, GameObject.Find("RESOURCE MANAGER").transform);

            newBuild.GetComponent<TrackProgress>().currentHp = data.Resources[i, 3];
            newBuild.GetComponent<TrackProgress>().deaths = (int) data.Resources[i, 4];

            if (newBuild.name == "Fir_Tree(Clone)")
                newBuild.GetComponent<TrackProgress>().hp = 20;
            else if (newBuild.name == "Rock1(Clone)")
                newBuild.GetComponent<TrackProgress>().hp = 40;
            else{
                newBuild.GetComponent<TrackProgress>().hp = 30;
            }
        }
    }
}