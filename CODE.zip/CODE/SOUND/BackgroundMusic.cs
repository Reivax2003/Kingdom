﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class BackgroundMusic : MonoBehaviour {
    public AudioSource MusicSource, BuildingSource, BirdsChirping, Wind;
    public Toggle MusicToggle, SoundToggle;
    public Slider MusicSlider, SoundSlider;
    public bool monOff = true;
    public bool sonOff = true;

    public void Start() {
        MusicSource.Play(0);
    }

    public void musicOnOff() {
        monOff = !monOff;

        if (monOff) {
            MusicSource.UnPause();
            MusicSource.volume = MusicSlider.value;
        } else {
            MusicSource.Pause();
        }
    }

    public void musicVolume() {
        MusicSource.volume = MusicSlider.value;
    }

    public void soundOnOff() {
        sonOff = !sonOff;

        if (sonOff) {
            BuildingSource.volume = SoundSlider.value;
            BirdsChirping.volume = SoundSlider.value;
            Wind.volume = SoundSlider.value;
        } else {
            BuildingSource.volume = 0f;
            BirdsChirping.volume = 0f;
            Wind.volume = 0f;
        }
    }

    public void soundVolume() {
        BuildingSource.volume = SoundSlider.value;
        BirdsChirping.volume = SoundSlider.value;
        Wind.volume = SoundSlider.value;
    }
}